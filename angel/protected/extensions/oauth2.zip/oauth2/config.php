<?php

return array(
	'weibo' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'qq' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'renren' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'taobao' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'360' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'douban' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'163' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'kaixin' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),

	'souhu' => array(
		'client_id' => '',
		'client_secret' => '',
		'enabled' => TRUE,
	),
);